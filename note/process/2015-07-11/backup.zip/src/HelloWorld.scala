/**
 * Created by root on 15-7-6.
 */
object HelloWorld {
  def main(args: Array[String]): Unit ={
    println("Hello world")
  }
}